-- SQLite scripts to setup product table.
INSERT INTO product VALUES (NULL, 'Rolling pin', 'This is a pin for rolling. Obviously.', 9.99);
INSERT INTO product VALUES (NULL, 'Spatula', 'Flip things! Disclaimer: We are not responsible for broken yolks!', 4.99);
INSERT INTO product VALUES (NULL, 'Pizza cutter', 'Much easier than picking up the whole pizza at once', 7.49);
INSERT INTO product VALUES (NULL, 'Coffee grinder', 'Grind your own beans. Look down on people who drink instant coffee', 39.99);

SELECT * FROM product;
